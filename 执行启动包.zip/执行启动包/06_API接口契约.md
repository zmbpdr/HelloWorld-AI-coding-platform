# 06 — API 接口契约

> **第一天必须定下来！** 所有人按此契约开发，不再需要反复沟通。
> 接口格式定好后，前端用 Mock 数据开发，后端写真实 API，最后联调时切换。

---

## 一、通用约定

- **Base URL：** `http://localhost:8000/api/v1`
- **认证方式：** JWT Bearer Token，在 Header 中传递 `Authorization: Bearer <token>`
- **Content-Type：** `application/json`
- **响应格式：** 成功返回数据，失败返回 `{"detail": "错误描述"}`
- **日期格式：** ISO 8601（如 `2024-01-15T14:30:00+00:00`）

---

## 二、能力诊断

### 获取诊断题目

```
GET /api/v1/diagnostic/questions
```

**响应：**
```json
{
  "questions": [
    {
      "id": 1,
      "question": "Python 中 print(type(42)) 的输出是什么？",
      "options": ["A. <class 'int'>", "B. <class 'str'>", "C. 42", "D. int"],
      "answer": "A",
      "tag": "数据类型"
    }
  ]
}
```

**注意：** 后端返回的 `answer` 字段仅供后端判断使用，前端不要展示。

### 提交诊断答案

```
POST /api/v1/diagnostic/submit
```

**请求体：**
```json
{
  "answers": [
    {"question_id": 1, "answer": "A"},
    {"question_id": 2, "answer": "C"}
  ]
}
```

**响应体：**
```json
{
  "score": 75,
  "skill_level": "intermediate",
  "correct_tags": ["变量", "print", "数据类型"],
  "weak_tags": ["循环", "函数"],
  "recommended_start": "python-05-loops",
  "message": "你已经掌握了变量和输出，但循环还需要加强。建议从第5关开始。"
}
```

---

## 三、AI 智能体

### 普通对话

```
POST /api/v1/ai/chat
```

**请求体：**
```json
{
  "message": "我不太理解循环的概念",
  "mode": "tutor",
  "context": {
    "lesson_title": "for 循环",
    "code": "for i in range(10):\n    print(i)"
  }
}
```

**响应体：**
```json
{
  "reply": "循环是编程中非常重要的概念。for i in range(10) 表示 i 从 0 到 9 依次取值..."
}
```

**mode 可选值：** `tutor`（导师）、`diagnostic`（诊断）、`review`（审查）、`planning`（规划）

### 流式对话

```
POST /api/v1/ai/chat/stream
```

请求体同上，响应为 SSE（Server-Sent Events）流。

### 结构化代码审查

```
POST /api/v1/ai/review
```

**请求体：**
```json
{
  "code": "def hello():\n    return 'hello'",
  "lesson_title": "Hello World",
  "test_results": [
    {"status": "passed", "expected": "hello", "actual": "hello"},
    {"status": "failed", "expected": "Hello, World!", "actual": "hello"}
  ]
}
```

**响应体：**
```json
{
  "correctness": 85,
  "readability": 70,
  "efficiency": 65,
  "compliance": 80,
  "problems": [
    {"line": 1, "severity": "warning", "message": "函数名 hello 比较通用，建议更具体"},
    {"line": 2, "severity": "error", "message": "返回值不正确，题目要求返回 'Hello, World!'"}
  ],
  "summary": "整体代码逻辑正确，但返回值与题目要求不一致，需要调整。",
  "next_action": "建议检查题目要求，确保输出格式正确。"
}
```

**降级响应（AI JSON 解析失败时）：**
```json
{
  "correctness": 0,
  "readability": 0,
  "efficiency": 0,
  "compliance": 0,
  "problems": [],
  "summary": "（AI 返回的纯文本内容）",
  "next_action": "",
  "fallback": true
}
```

### 错误分类

```
POST /api/v1/ai/classify-error
```

**请求体：**
```json
{
  "code": "print(name",
  "stderr": "SyntaxError: unexpected EOF while parsing",
  "test_results": []
}
```

**响应体：**
```json
{
  "error_type": "syntax",
  "analysis": "代码缺少右括号，print(name) 应该是 print(name)"
}
```

---

## 四、错题本

### 获取错题列表

```
GET /api/v1/errors?type=syntax&resolved=false
```

**参数：**
- `type`（可选）：筛选类型 `syntax` / `logic` / `boundary` / `performance`
- `resolved`（可选）：`true` 只显示已解决，`false` 只显示未解决

**响应体：**
```json
{
  "errors": [
    {
      "id": 1,
      "lesson_id": 3,
      "error_type": "syntax",
      "error_code": "print(name",
      "ai_analysis": "缺少右括号",
      "is_resolved": false,
      "created_at": "2024-01-15T14:30:00+00:00"
    }
  ],
  "stats": {
    "syntax": 5,
    "logic": 3,
    "boundary": 1,
    "performance": 0
  }
}
```

### 标记错题已解决

```
PATCH /api/v1/errors/{error_id}/resolve
```

**响应体：**
```json
{
  "id": 1,
  "is_resolved": true
}
```

---

## 五、知识掌握度

### 获取知识掌握度

```
GET /api/v1/progress/knowledge
```

**响应体：**
```json
{
  "knowledge": [
    {
      "tag": "变量",
      "mastery": 90.0,
      "total_attempts": 5,
      "correct_count": 4,
      "last_practice_at": "2024-01-15T10:00:00+00:00"
    },
    {
      "tag": "循环",
      "mastery": 35.0,
      "total_attempts": 8,
      "correct_count": 2,
      "last_practice_at": "2024-01-14T16:00:00+00:00"
    }
  ]
}
```

---

## 六、个性化推荐

### 获取推荐关卡

```
GET /api/v1/lessons/recommend?language=python
```

**响应体：**
```json
{
  "recommended": [
    {
      "slug": "python-05-loops",
      "title": "循环",
      "reason": "覆盖薄弱知识点: 循环",
      "tags": ["循环", "range"]
    },
    {
      "slug": "python-06-lists",
      "title": "列表",
      "reason": "下一关待学习",
      "tags": []
    }
  ],
  "knowledge_map": {
    "变量": 90.0,
    "循环": 35.0,
    "函数": 60.0
  }
}
```

---

## 七、Lesson 模型扩展

### 关卡详情响应增加字段

```
GET /api/v1/lessons/{slug}
```

**响应体（在现有字段基础上增加）：**
```json
{
  "id": 1,
  "slug": "python-01-hello-world",
  "title": "Hello World",
  "knowledge_tags": ["print", "字符串"],
  "estimated_minutes": 10,
  "prerequisites": []
}
```

---

## 八、接口总览

| 方法 | 路径 | 用途 | 负责人 |
|------|------|------|:------:|
| GET | `/diagnostic/questions` | 获取诊断题目 | A |
| POST | `/diagnostic/submit` | 提交诊断答案 | A |
| POST | `/ai/chat` | AI 对话 | B |
| POST | `/ai/chat/stream` | AI 流式对话 | B |
| POST | `/ai/review` | 结构化代码审查 | B |
| POST | `/ai/classify-error` | 错误分类 | B |
| GET | `/errors` | 获取错题列表 | A |
| PATCH | `/errors/{id}/resolve` | 标记已解决 | A |
| GET | `/progress/knowledge` | 获取知识掌握度 | A |
| GET | `/lessons/recommend` | 获取推荐关卡 | D |

---

## 九、前端 Mock 数据参考

在等待后端 API 完成期间，前端可以使用以下 Mock 数据：

```typescript
// mock/diagnostic.ts
export const mockDiagnosticResult = {
  score: 75,
  skill_level: "intermediate",
  correct_tags: ["变量", "print", "数据类型"],
  weak_tags: ["循环", "函数"],
  recommended_start: "python-05-loops",
  message: "你已经掌握了变量和输出，但循环还需要加强。建议从第5关开始。",
};

// mock/review.ts
export const mockReviewResult = {
  correctness: 85,
  readability: 70,
  efficiency: 65,
  compliance: 80,
  problems: [
    { line: 5, severity: "warning", message: "变量名 a 不够描述性，建议改为 user_count" },
    { line: 12, severity: "error", message: "循环边界可能错误，建议使用 len()-1" },
  ],
  summary: "整体代码逻辑正确，但可读性和效率有提升空间。",
  next_action: "建议重新练习列表遍历",
};

// mock/knowledge.ts
export const mockKnowledge = [
  { tag: "变量", mastery: 90, total_attempts: 5 },
  { tag: "循环", mastery: 35, total_attempts: 8 },
  { tag: "函数", mastery: 60, total_attempts: 3 },
  { tag: "列表", mastery: 80, total_attempts: 4 },
  { tag: "条件判断", mastery: 95, total_attempts: 6 },
];

// mock/errors.ts
export const mockErrors = {
  errors: [
    { id: 1, error_type: "syntax", error_code: "print(name", ai_analysis: "缺少右括号", is_resolved: false },
    { id: 2, error_type: "logic", error_code: "for i in range(1,10)", ai_analysis: "range(1,10) 不包含 10", is_resolved: false },
  ],
  stats: { syntax: 5, logic: 3, boundary: 1, performance: 0 },
};
```